//
//  AccountDetailViewModelTests.swift
//  Aura
//
//  Created by Renaud Leroy on 21/07/2025.
//

import XCTest
@testable import Aura

final class AccountDetailViewModelTests: XCTestCase {
    
    func testAccountSuccess() async {
        let apiService = MockAPIService()
        let keychainService = MockKeychainService()
        keychainService.saved["auth_token"] = "mock_token"
        
        let viewModel = AccountDetailViewModel(
            keychainService: keychainService,
            apiService: apiService
        )
        
        let mockTransactions = [
            AccountDetailViewModel.Transaction(label: "Payment1", value: 150.0),
            AccountDetailViewModel.Transaction(label: "Payment2", value: 500.0)
        ]

        let mockBalance: Double = 650.0
        await viewModel.account()
        
        XCTAssertEqual(viewModel.transactions, mockTransactions)
        XCTAssertEqual(viewModel.currentBalance, mockBalance)
    }
}
